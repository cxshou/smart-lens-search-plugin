(function () {
  let overlay = null;
  let selectionBox = null;
  let startX = 0, startY = 0;
  let isSelecting = false;
  let currentEngine = 'googleLens';
  let shortcutBindings = {
    capture_area: 'Ctrl+Shift+X',
    capture_lens: 'Ctrl+Shift+V',
    capture_chatgpt: 'Ctrl+Shift+Z'
  };

  const handlers = {};

  initShortcuts();

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.action === 'activateSelection') {
      currentEngine = message.engine || 'googleLens';
      createOverlay();
      sendResponse({ success: true });
    }

    if (message.action === 'copyToClipboard') {
      copyToClipboard(message.imageDataUrl).then(function () {
        sendResponse({ success: true });
      }).catch(function () {
        sendResponse({ success: false });
      });
      return true;
    }
  });

  function createOverlay() {
    cleanup();

    overlay = document.createElement('div');
    overlay.id = '__sl_overlay__';
    overlay.style.cssText =
      'position:fixed;top:0;left:0;width:100vw;height:100vh;' +
      'z-index:2147483647;cursor:crosshair;' +
      'background:rgba(0,0,0,0.2);';

    selectionBox = document.createElement('div');
    selectionBox.id = '__sl_box__';
    selectionBox.style.cssText =
      'position:fixed;z-index:2147483647;pointer-events:none;' +
      'border:2px dashed #4A90D9;background:rgba(74,144,217,0.13);' +
      'display:none;border-radius:2px;';

    var body = document.body || document.documentElement;
    body.appendChild(overlay);
    body.appendChild(selectionBox);

    handlers.mousedown = onMouseDown;
    handlers.mousemove = onMouseMove;
    handlers.mouseup   = onMouseUp;
    handlers.keydown   = onKeyDown;

    overlay.addEventListener('mousedown', handlers.mousedown);
    overlay.addEventListener('mousemove', handlers.mousemove);
    overlay.addEventListener('mouseup',   handlers.mouseup);
    document.addEventListener('keydown',  handlers.keydown, true);
  }

  function initShortcuts() {
    chrome.storage.local.get('shortcutBindings', function (result) {
      if (result.shortcutBindings) {
        shortcutBindings = result.shortcutBindings;
      }
    });

    chrome.storage.onChanged.addListener(function (changes, areaName) {
      if (areaName !== 'local' || !changes.shortcutBindings) return;
      shortcutBindings = changes.shortcutBindings.newValue || shortcutBindings;
    });

    document.addEventListener('keydown', onShortcutKeydown, true);
  }

  function onShortcutKeydown(e) {
    if (e.repeat) return;
    if (overlay) return;
    if (e.defaultPrevented) return;
    if (e.metaKey || e.altKey) return;

    var combo = formatShortcut(e);
    if (!combo) return;

    var command = findShortcutCommand(combo);
    if (!command) return;

    e.preventDefault();
    e.stopPropagation();
    chrome.runtime.sendMessage({
      action: 'triggerShortcutCommand',
      command: command
    }).catch(function () {});
  }

  function findShortcutCommand(combo) {
    var keys = Object.keys(shortcutBindings || {});
    for (var i = 0; i < keys.length; i++) {
      if (normalizeShortcut(shortcutBindings[keys[i]]) === combo) {
        return keys[i];
      }
    }
    return null;
  }

  function formatShortcut(e) {
    var key = normalizeKey(e.key);
    if (!key) return '';
    var parts = [];
    if (e.ctrlKey) parts.push('Ctrl');
    if (e.shiftKey) parts.push('Shift');
    parts.push(key);
    return parts.join('+');
  }

  function normalizeShortcut(value) {
    if (!value) return '';
    var parts = String(value).split('+').map(function (part) {
      return part.trim();
    }).filter(Boolean);
    if (parts.length === 0) return '';
    var normalized = [];
    var hasCtrl = false;
    var hasShift = false;
    var key = '';
    for (var i = 0; i < parts.length; i++) {
      var part = parts[i].toLowerCase();
      if (part === 'ctrl' || part === 'control') hasCtrl = true;
      else if (part === 'shift') hasShift = true;
      else key = normalizeKey(parts[i]);
    }
    if (hasCtrl) normalized.push('Ctrl');
    if (hasShift) normalized.push('Shift');
    if (key) normalized.push(key);
    return normalized.join('+');
  }

  function normalizeKey(key) {
    if (!key) return '';
    if (key.length === 1) return key.toUpperCase();
    return '';
  }

  function onMouseDown(e) {
    e.preventDefault();
    e.stopPropagation();
    isSelecting = true;
    startX = e.clientX;
    startY = e.clientY;
    selectionBox.style.display = 'block';
    updateBox(e.clientX, e.clientY);
  }

  function onMouseMove(e) {
    if (!isSelecting) return;
    e.preventDefault();
    updateBox(e.clientX, e.clientY);
  }

  function onMouseUp(e) {
    if (!isSelecting) return;
    isSelecting = false;
    e.preventDefault();

    var x = Math.min(startX, e.clientX);
    var y = Math.min(startY, e.clientY);
    var w = Math.abs(e.clientX - startX);
    var h = Math.abs(e.clientY - startY);

    cleanup();

    if (w < 12 || h < 12) return;

    chrome.runtime.sendMessage({
      action: 'areaSelected',
      data: {
        x: Math.round(x),
        y: Math.round(y),
        width: Math.round(w),
        height: Math.round(h),
        dpr: window.devicePixelRatio || 1,
        engine: currentEngine
      }
    });
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      cleanup();
    }
  }

  function updateBox(mx, my) {
    var l = Math.min(startX, mx);
    var t = Math.min(startY, my);
    var w = Math.abs(mx - startX);
    var h = Math.abs(my - startY);
    selectionBox.style.left   = l + 'px';
    selectionBox.style.top    = t + 'px';
    selectionBox.style.width  = w + 'px';
    selectionBox.style.height = h + 'px';
  }

  function cleanup() {
    if (overlay) {
      overlay.removeEventListener('mousedown', handlers.mousedown);
      overlay.removeEventListener('mousemove', handlers.mousemove);
      overlay.removeEventListener('mouseup',   handlers.mouseup);
      document.removeEventListener('keydown',  handlers.keydown, true);
      overlay.remove();
      overlay = null;
    }
    if (selectionBox) {
      selectionBox.remove();
      selectionBox = null;
    }
  }

  function copyToClipboard(dataUrl) {
    return fetch(dataUrl)
      .then(function (r) { return r.blob(); })
      .then(function (blob) {
        var item = new ClipboardItem({ 'image/png': blob });
        return navigator.clipboard.write([item]);
      })
      .then(function () {
        showToast('Captured & sending...');
      });
  }

  function showToast(msg) {
    var toast = document.createElement('div');
    toast.textContent = msg;
    toast.id = '__sl_toast__';
    toast.style.cssText =
      'position:fixed;bottom:28px;left:50%;transform:translateX(-50%);' +
      'z-index:2147483647;background:#1e1e2e;color:#cdd6f4;' +
      'padding:10px 22px;border-radius:8px;font-size:13px;' +
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;' +
      'pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);' +
      'animation:__sl_slideUp 0.3s ease;';
    (document.body || document.documentElement).appendChild(toast);

    setTimeout(function () {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s';
      setTimeout(function () { toast.remove(); }, 300);
    }, 2000);
  }
})();
