(function () {
  let overlay = null;
  let selectionBox = null;
  let textBubble = null;
  let textBubbleHideTimer = null;
  let lastSelectionPoint = null;
  let startX = 0, startY = 0;
  let isSelecting = false;
  let currentEngine = 'googleLens';
  let shortcutBindings = {
    capture_area: 'Ctrl+Shift+X',
    capture_lens: 'Ctrl+Shift+V',
    capture_chatgpt: 'Ctrl+Shift+Z'
  };

  const handlers = {};

  initShortcuts();
  initTextBubble();

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.action === 'activateSelection') {
      currentEngine = message.engine || 'googleLens';
      createOverlay();
      sendResponse({ success: true });
    }

    if (message.action === 'copyToClipboard') {
      copyToClipboard(message.imageDataUrl).then(function () {
        sendResponse({ success: true });
      }).catch(function () {
        sendResponse({ success: false });
      });
      return true;
    }
  });

  function createOverlay() {
    cleanup();

    overlay = document.createElement('div');
    overlay.id = '__sl_overlay__';
    overlay.style.cssText =
      'position:fixed;top:0;left:0;width:100vw;height:100vh;' +
      'z-index:2147483647;cursor:crosshair;' +
      'background:rgba(0,0,0,0.2);';

    selectionBox = document.createElement('div');
    selectionBox.id = '__sl_box__';
    selectionBox.style.cssText =
      'position:fixed;z-index:2147483647;pointer-events:none;' +
      'border:2px dashed #4A90D9;background:rgba(74,144,217,0.13);' +
      'display:none;border-radius:2px;';

    var body = document.body || document.documentElement;
    body.appendChild(overlay);
    body.appendChild(selectionBox);

    handlers.mousedown = onMouseDown;
    handlers.mousemove = onMouseMove;
    handlers.mouseup   = onMouseUp;
    handlers.keydown   = onKeyDown;

    overlay.addEventListener('mousedown', handlers.mousedown);
    overlay.addEventListener('mousemove', handlers.mousemove);
    overlay.addEventListener('mouseup',   handlers.mouseup);
    document.addEventListener('keydown',  handlers.keydown, true);
  }

  function initShortcuts() {
    chrome.storage.local.get('shortcutBindings', function (result) {
      if (result.shortcutBindings) {
        shortcutBindings = result.shortcutBindings;
      }
    });

    chrome.storage.onChanged.addListener(function (changes, areaName) {
      if (areaName !== 'local' || !changes.shortcutBindings) return;
      shortcutBindings = changes.shortcutBindings.newValue || shortcutBindings;
    });

    document.addEventListener('keydown', onShortcutKeydown, true);
  }

  function initTextBubble() {
    document.addEventListener('mouseup', onTextSelectionChange, true);
    document.addEventListener('selectionchange', onSelectionChangePassive, true);
    document.addEventListener('scroll', hideTextBubble, true);
    document.addEventListener('mousedown', onDocumentMouseDown, true);
  }

  function onSelectionChangePassive() {
    if (!textBubble) return;
    var selection = window.getSelection();
    if (selection && selection.toString().trim()) return;
    hideTextBubble();
  }

  function onDocumentMouseDown(e) {
    if (!textBubble || textBubble.style.display === 'none') return;
    if (textBubble.contains(e.target)) return;
    hideTextBubble();
  }

  function onTextSelectionChange() {
    if (overlay) return;

    clearTimeout(textBubbleHideTimer);
    textBubbleHideTimer = setTimeout(function () {
      var selection = window.getSelection();
      var text = selection ? selection.toString().trim() : '';
      if (!text) {
        hideTextBubble();
        return;
      }

      if (!selection.rangeCount) {
        hideTextBubble();
        return;
      }

      var rect = selection.getRangeAt(0).getBoundingClientRect();
      if (!rect || (!rect.width && !rect.height)) {
        hideTextBubble();
        return;
      }

      showTextBubble(rect);
    }, 60);
  }

  function showTextBubble(rect) {
    if (!textBubble) {
      textBubble = document.createElement('button');
      textBubble.type = 'button';
      textBubble.id = '__sl_text_bubble__';
      textBubble.textContent = '嗖一下~';
        textBubble.style.cssText =
          'position:fixed;z-index:2147483647;border:none;outline:none;' +
          'background:rgba(207,233,255,0.6);color:#ff9500;padding:7px 12px;border-radius:999px;' +
          'font:12px/1.2 system-ui,sans-serif;font-weight:700;' +
          'box-shadow:0 10px 28px rgba(34,92,150,0.22);cursor:pointer;' +
          'border:1px solid rgba(108,167,229,0.65);' +
        'transition:opacity .18s ease,transform .18s ease;';
      textBubble.addEventListener('mousedown', function (e) {
        e.preventDefault();
        e.stopPropagation();
      });
      textBubble.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        triggerSelectedTextSearch();
      });
      (document.body || document.documentElement).appendChild(textBubble);
    }

    clearTimeout(textBubbleHideTimer);

    var bubbleX = lastSelectionPoint ? lastSelectionPoint.x + 18 : rect.left + rect.width;
    var bubbleY = lastSelectionPoint ? lastSelectionPoint.y - 18 : rect.top - 18;
    var top = Math.max(12, bubbleY - 26);
    var left = Math.max(40, bubbleX);

    textBubble.style.top = top + 'px';
    textBubble.style.left = left + 'px';
    textBubble.style.animation = 'none';
    textBubble.style.opacity = '1';
    textBubble.style.display = 'block';
    textBubble.style.transform = 'translate(-50%, 0) scale(1)';
    void textBubble.offsetWidth;
    textBubble.style.animation = '__sl_bubblePop 260ms cubic-bezier(.22,1.28,.32,1)';

    textBubbleHideTimer = setTimeout(function () {
      fadeOutTextBubble();
    }, 5000);
  }

  function hideTextBubble() {
    if (!textBubble) return;
    clearTimeout(textBubbleHideTimer);
    textBubble.style.animation = 'none';
    textBubble.style.display = 'none';
  }

  function fadeOutTextBubble() {
    if (!textBubble || textBubble.style.display === 'none') return;
    clearTimeout(textBubbleHideTimer);
    textBubble.style.animation = '__sl_bubbleFade 180ms ease forwards';
    setTimeout(function () {
      if (!textBubble) return;
      textBubble.style.display = 'none';
      textBubble.style.animation = 'none';
      textBubble.style.opacity = '1';
    }, 180);
  }

  function triggerSelectedTextSearch() {
    var selection = window.getSelection();
    var text = selection ? selection.toString().trim() : '';
    if (!text) {
      hideTextBubble();
      return;
    }

    chrome.runtime.sendMessage({
      action: 'searchSelectedText',
      text: text
    }).catch(function () {});

    hideTextBubble();
  }

  function onShortcutKeydown(e) {
    if (e.repeat) return;
    if (overlay) return;
    if (e.defaultPrevented) return;
    if (e.metaKey || e.altKey) return;

    var combo = formatShortcut(e);
    if (!combo) return;

    var command = findShortcutCommand(combo);
    if (!command) return;

    e.preventDefault();
    e.stopPropagation();
    chrome.runtime.sendMessage({
      action: 'triggerShortcutCommand',
      command: command
    }).catch(function () {});
  }

  function findShortcutCommand(combo) {
    var keys = Object.keys(shortcutBindings || {});
    for (var i = 0; i < keys.length; i++) {
      if (normalizeShortcut(shortcutBindings[keys[i]]) === combo) {
        return keys[i];
      }
    }
    return null;
  }

  function formatShortcut(e) {
    var key = normalizeKey(e.key);
    if (!key) return '';
    var parts = [];
    if (e.ctrlKey) parts.push('Ctrl');
    if (e.shiftKey) parts.push('Shift');
    parts.push(key);
    return parts.join('+');
  }

  function normalizeShortcut(value) {
    if (!value) return '';
    var parts = String(value).split('+').map(function (part) {
      return part.trim();
    }).filter(Boolean);
    if (parts.length === 0) return '';
    var normalized = [];
    var hasCtrl = false;
    var hasShift = false;
    var key = '';
    for (var i = 0; i < parts.length; i++) {
      var part = parts[i].toLowerCase();
      if (part === 'ctrl' || part === 'control') hasCtrl = true;
      else if (part === 'shift') hasShift = true;
      else key = normalizeKey(parts[i]);
    }
    if (hasCtrl) normalized.push('Ctrl');
    if (hasShift) normalized.push('Shift');
    if (key) normalized.push(key);
    return normalized.join('+');
  }

  function normalizeKey(key) {
    if (!key) return '';
    if (key.length === 1) return key.toUpperCase();
    return '';
  }

  function onMouseDown(e) {
    e.preventDefault();
    e.stopPropagation();
    isSelecting = true;
    startX = e.clientX;
    startY = e.clientY;
    selectionBox.style.display = 'block';
    updateBox(e.clientX, e.clientY);
  }

  function onMouseMove(e) {
    if (!isSelecting) return;
    e.preventDefault();
    updateBox(e.clientX, e.clientY);
  }

  function onMouseUp(e) {
    if (!isSelecting) return;
    isSelecting = false;
    e.preventDefault();

    var x = Math.min(startX, e.clientX);
    var y = Math.min(startY, e.clientY);
    var w = Math.abs(e.clientX - startX);
    var h = Math.abs(e.clientY - startY);

    cleanup();

    if (w < 12 || h < 12) return;

    chrome.runtime.sendMessage({
      action: 'areaSelected',
      data: {
        x: Math.round(x),
        y: Math.round(y),
        width: Math.round(w),
        height: Math.round(h),
        dpr: window.devicePixelRatio || 1,
        engine: currentEngine
      }
    });
  }

  document.addEventListener('mouseup', function (e) {
    lastSelectionPoint = { x: e.clientX, y: e.clientY };
  }, true);

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      cleanup();
    }
  }

  function updateBox(mx, my) {
    var l = Math.min(startX, mx);
    var t = Math.min(startY, my);
    var w = Math.abs(mx - startX);
    var h = Math.abs(my - startY);
    selectionBox.style.left   = l + 'px';
    selectionBox.style.top    = t + 'px';
    selectionBox.style.width  = w + 'px';
    selectionBox.style.height = h + 'px';
  }

  function cleanup() {
    if (overlay) {
      overlay.removeEventListener('mousedown', handlers.mousedown);
      overlay.removeEventListener('mousemove', handlers.mousemove);
      overlay.removeEventListener('mouseup',   handlers.mouseup);
      document.removeEventListener('keydown',  handlers.keydown, true);
      overlay.remove();
      overlay = null;
    }
    if (selectionBox) {
      selectionBox.remove();
      selectionBox = null;
    }
  }

  function copyToClipboard(dataUrl) {
    return fetch(dataUrl)
      .then(function (r) { return r.blob(); })
      .then(function (blob) {
        var item = new ClipboardItem({ 'image/png': blob });
        return navigator.clipboard.write([item]);
      })
      .then(function () {
        showToast('Captured & sending...');
      });
  }

  function showToast(msg) {
    var toast = document.createElement('div');
    toast.textContent = msg;
    toast.id = '__sl_toast__';
    toast.style.cssText =
      'position:fixed;bottom:28px;left:50%;transform:translateX(-50%);' +
      'z-index:2147483647;background:#1e1e2e;color:#cdd6f4;' +
      'padding:10px 22px;border-radius:8px;font-size:13px;' +
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;' +
      'pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);' +
      'animation:__sl_slideUp 0.3s ease;';
    (document.body || document.documentElement).appendChild(toast);

    setTimeout(function () {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s';
      setTimeout(function () { toast.remove(); }, 300);
    }, 2000);
  }
})();
