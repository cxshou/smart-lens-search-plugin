document.addEventListener('DOMContentLoaded', function () {
  var shortcutBody = document.getElementById('shortcutBody');
  var openShortcuts = document.getElementById('openShortcuts');
  var lastCommandInfo = document.getElementById('lastCommandInfo');
  var commandLabels = {
    capture_area: 'Capture area (last selected engine)'
  };

  chrome.commands.getAll(function (commands) {
    commands.forEach(function (cmd) {
      var tr = document.createElement('tr');
      var tdDesc = document.createElement('td');
      tdDesc.textContent = commandLabels[cmd.name] || cmd.description || cmd.name;
      var tdKey = document.createElement('td');
      var kbd = document.createElement('kbd');
      kbd.textContent = cmd.shortcut || '(not set — click Customize to add)';
      if (!cmd.shortcut) kbd.style.color = '#6c7086';
      tdKey.appendChild(kbd);
      tr.appendChild(tdDesc);
      tr.appendChild(tdKey);
      shortcutBody.appendChild(tr);
    });
  });

  chrome.storage.local.get('lastCommandInfo', function (result) {
    if (!result.lastCommandInfo) return;
    var info = result.lastCommandInfo;
    var when = new Date(info.receivedAt);
    var label = commandLabels[info.command] || info.command;
    lastCommandInfo.textContent = 'Last shortcut command received by the extension: ' + label + ' at ' + when.toLocaleTimeString();
  });

  openShortcuts.addEventListener('click', function (e) {
    e.preventDefault();
    chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
  });
});
