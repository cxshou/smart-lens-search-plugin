document.addEventListener('DOMContentLoaded', function () {
  var radios = document.querySelectorAll('input[name="engine"]');
  var captureBtn = document.getElementById('captureBtn');
  var bindingCaptureArea = document.getElementById('bindingCaptureArea');
  var bindingCaptureLens = document.getElementById('bindingCaptureLens');
  var bindingCaptureChatGPT = document.getElementById('bindingCaptureChatGPT');
  var saveBindingsBtn = document.getElementById('saveBindingsBtn');
  var resetBindingsBtn = document.getElementById('resetBindingsBtn');
  var bindingStatus = document.getElementById('bindingStatus');

  var commandOrder = ['capture_area', 'capture_lens', 'capture_chatgpt'];
  var defaultBindings = {
    capture_area: 'Ctrl+Shift+X',
    capture_lens: 'Ctrl+Shift+V',
    capture_chatgpt: 'Ctrl+Shift+Z'
  };
  var draftBindings = Object.assign({}, defaultBindings);

  // Load saved preference
  chrome.storage.local.get('lastEngine', function (result) {
    if (result.lastEngine) {
      var radio = document.querySelector('input[value="' + result.lastEngine + '"]');
      if (radio) radio.checked = true;
    }
  });

  radios.forEach(function (r) {
    r.addEventListener('change', function () {
      chrome.storage.local.set({ lastEngine: this.value });
    });
  });

  setupBindingInput(bindingCaptureArea, 'capture_area');
  setupBindingInput(bindingCaptureLens, 'capture_lens');
  setupBindingInput(bindingCaptureChatGPT, 'capture_chatgpt');

  saveBindingsBtn.addEventListener('click', function () {
    var validationError = validateBindings(draftBindings);
    if (validationError) {
      bindingStatus.textContent = validationError;
      return;
    }
    chrome.storage.local.set({ shortcutBindings: Object.assign({}, draftBindings) }, function () {
      bindingStatus.textContent = 'Saved page fallback shortcuts.';
      loadBindings();
    });
  });

  resetBindingsBtn.addEventListener('click', function () {
    draftBindings = Object.assign({}, defaultBindings);
    renderBindingInputs();
    bindingStatus.textContent = 'Reset to defaults. Click Save to apply.';
  });

  // Capture button
  captureBtn.addEventListener('click', function () {
    var selected = document.querySelector('input[name="engine"]:checked');
    var engine = selected ? selected.value : 'chatgpt';
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs[0]) return;
      chrome.runtime.sendMessage({ action: 'startCapture', engine: engine }, function () {
        window.close();
      });
    });
  });

  loadBindings();

  function loadBindings() {
    chrome.storage.local.get('shortcutBindings', function (result) {
      draftBindings = Object.assign({}, defaultBindings, result.shortcutBindings || {});
      renderBindingInputs();
    });
  }

  function renderBindingInputs() {
    bindingCaptureArea.value = extractLetter(draftBindings.capture_area);
    bindingCaptureLens.value = extractLetter(draftBindings.capture_lens);
    bindingCaptureChatGPT.value = extractLetter(draftBindings.capture_chatgpt);
  }

  function setupBindingInput(input, commandName) {
    input.addEventListener('focus', function () {
      bindingStatus.textContent = 'Enter one letter for ' + getCommandLabel(commandName) + '. Prefix stays Ctrl+Shift+.';
    });

    input.addEventListener('input', function () {
      var letter = normalizeLetter(input.value);
      input.value = letter;
      if (!letter) {
        bindingStatus.textContent = 'Use A-Z only.';
        return;
      }
      draftBindings[commandName] = 'Ctrl+Shift+' + letter;
      bindingStatus.textContent = 'Recorded Ctrl+Shift+' + letter + '. Click Save to apply.';
    });
  }

  function getCommandLabel(commandName) {
    if (commandName === 'capture_area') return 'Last selected engine';
    if (commandName === 'capture_lens') return 'Google';
    if (commandName === 'capture_chatgpt') return 'ChatGPT';
    return commandName;
  }

  function normalizeLetter(key) {
    if (!key || key.length !== 1) return '';
    var upper = key.toUpperCase();
    return /^[A-Z]$/.test(upper) ? upper : '';
  }

  function extractLetter(shortcut) {
    if (!shortcut) return '';
    var parts = String(shortcut).split('+');
    return normalizeLetter(parts[parts.length - 1] || '');
  }

  function validateBindings(bindings) {
    var seen = {};
    for (var i = 0; i < commandOrder.length; i++) {
      var name = commandOrder[i];
      var value = bindings[name];
      if (!value) return 'All three page fallback shortcuts are required.';
      if (seen[value]) return 'Duplicate shortcut: ' + value;
      seen[value] = true;
    }
    return '';
  }
});
