var ENGINES = {
  google: 'https://www.google.com',
  chatgpt: 'https://chatgpt.com'
};
var DEFAULT_ENGINE = 'chatgpt';
var DEFAULT_SHORTCUT_BINDINGS = {
  capture_area: 'Ctrl+Shift+X',
  capture_lens: 'Ctrl+Shift+V',
  capture_chatgpt: 'Ctrl+Shift+Z'
};

// ---- Install ----
chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.create({
    id: 'slTextChatGPT',
    title: 'Search selected text with ChatGPT',
    contexts: ['selection']
  });

  chrome.storage.local.get('shortcutBindings', function (result) {
    if (!result.shortcutBindings) {
      chrome.storage.local.set({ shortcutBindings: DEFAULT_SHORTCUT_BINDINGS });
    }
  });
});

// ---- Context menu clicks ----
chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId === 'slTextChatGPT') {
    var text = (info.selectionText || '').trim();
    if (text) openWithText('chatgpt', text);
  }
});

// ---- Keyboard shortcuts ----
chrome.commands.onCommand.addListener(function (command, tab) {
  recordLastCommand(command, 'chrome.commands');
  handleCommand(command, tab);
});

function recordLastCommand(command, source) {
  var info = {
    command: command,
    source: source || 'unknown',
    receivedAt: Date.now()
  };
  var payload = { lastCommandInfo: info };
  if (info.source === 'chrome.commands') {
    payload.lastChromeCommandInfo = info;
  }
  if (info.source === 'content.keydown') {
    payload.lastContentCommandInfo = info;
  }
  chrome.storage.local.set(payload).catch(function () {});
}

function recordCommandResult(info) {
  chrome.storage.local.set({
    lastCommandResult: info
  }).catch(function () {});
}

async function handleCommand(command, commandTab) {
  var engine = null;
  var startedAt = Date.now();
  try {
    switch (command) {
      case 'capture_area':
        engine = await getLastSelectedEngine();
        break;
      case 'capture_lens':
        engine = 'google';
        break;
      case 'capture_chatgpt':
        engine = 'chatgpt';
        break;
      default:
        return;
    }

    var tab = commandTab && isInjectableTab(commandTab)
      ? commandTab
      : await getActiveInjectableTab();
    if (!tab) {
      recordCommandResult({
        command: command,
        engine: engine,
        ok: false,
        stage: 'tab',
        error: 'No injectable active tab',
        finishedAt: Date.now(),
        durationMs: Date.now() - startedAt
      });
      return;
    }

    await startCapture(tab.id, engine);
    recordCommandResult({
      command: command,
      engine: engine,
      ok: true,
      stage: 'startCapture',
      tabId: tab.id,
      url: tab.url,
      finishedAt: Date.now(),
      durationMs: Date.now() - startedAt
    });
  } catch (e) {
    console.error('[SmartLens] Command handler error:', e);
    recordCommandResult({
      command: command,
      engine: engine,
      ok: false,
      stage: 'startCapture',
      error: e && e.message ? e.message : String(e),
      finishedAt: Date.now(),
      durationMs: Date.now() - startedAt
    });
  }
}

async function getLastSelectedEngine() {
  var result = await promisify(chrome.storage.local.get, chrome.storage.local, ['lastEngine']);
  var engine = result.lastEngine || DEFAULT_ENGINE;
  return ENGINES[engine] ? engine : DEFAULT_ENGINE;
}

async function getActiveInjectableTab() {
  var tabs = await promisify(chrome.tabs.query, chrome.tabs, [{ active: true, currentWindow: true }]);
  if (!tabs || !tabs[0]) return null;
  return isInjectableTab(tabs[0]) ? tabs[0] : null;
}

function isInjectableTab(tab) {
  if (!tab || !tab.id || !tab.url) return false;
  return tab.url.indexOf('http://') === 0 || tab.url.indexOf('https://') === 0;
}

function promisify(fn, ctx, args) {
  return new Promise(function (resolve, reject) {
    try {
      fn.apply(ctx, (args || []).concat([function (result) {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        resolve(result);
      }]));
    } catch (e) {
      reject(e);
    }
  });
}

// ---- Popup messages ----
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === 'triggerShortcutCommand') {
    recordLastCommand(message.command, 'content.keydown');
    handleCommand(message.command, sender.tab)
      .then(function () {
        sendResponse({ success: true });
      })
      .catch(function (e) {
        console.error('[SmartLens] triggerShortcutCommand error:', e);
        sendResponse({ success: false });
      });
    return true;
  }

  if (message.action === 'startCapture') {
    (async function () {
      try {
        var engine = ENGINES[message.engine] ? message.engine : DEFAULT_ENGINE;
        var tab = await getActiveInjectableTab();
        if (!tab) {
          sendResponse({ success: false }); return;
        }
        await promisify(chrome.storage.local.set, chrome.storage.local, [{ lastEngine: engine }]);
        await startCapture(tab.id, engine);
        sendResponse({ success: true });
      } catch (e) {
        console.error('[SmartLens] startCapture error:', e);
        sendResponse({ success: false });
      }
    })();
    return true;
  }

  if (message.action === 'areaSelected') {
    handleAreaSelected(sender.tab.id, message.data)
      .then(function () {
        sendResponse({ success: true });
      })
      .catch(function (e) {
        console.error('[SmartLens] areaSelected error:', e);
        sendResponse({ success: false });
      });
    return true;
  }
});

// ---- Capture flow ----
async function startCapture(tabId, engine) {
  engine = ENGINES[engine] ? engine : DEFAULT_ENGINE;

  for (var i = 0; i < 2; i++) {
    if (await sendActivateSelection(tabId, engine)) return;
    await delay(150);
  }

  await chrome.scripting.executeScript({
    target: { tabId: tabId },
    files: ['content.js']
  });
  await chrome.scripting.insertCSS({
    target: { tabId: tabId },
    files: ['content.css']
  });
  await delay(200);

  if (await sendActivateSelection(tabId, engine)) return;
  throw new Error('Content script did not respond after injection');
}

async function sendActivateSelection(tabId, engine) {
  try {
    var resp = await chrome.tabs.sendMessage(tabId, {
      action: 'activateSelection',
      engine: engine
    });
    return !!(resp && resp.success);
  } catch (_) {
    return false;
  }
}

function delay(ms) {
  return new Promise(function (resolve) {
    setTimeout(resolve, ms);
  });
}

function handleAreaSelected(tabId, data) {
  var engine = data.engine;
  return captureVisibleTab()
    .then(function (fullDataUrl) {
      return cropImage(fullDataUrl, data.x, data.y, data.width, data.height, data.dpr);
    })
    .then(function (croppedDataUrl) {
      return chrome.storage.local.set({ captureImage: croppedDataUrl })
        .then(function () { return croppedDataUrl; });
    })
    .then(function (croppedDataUrl) {
      return chrome.tabs.sendMessage(tabId, {
        action: 'copyToClipboard',
        imageDataUrl: croppedDataUrl
      }).catch(function () {}).then(function () {
        return croppedDataUrl;
      });
    })
    .then(function (croppedDataUrl) {
      return openEngine(engine, croppedDataUrl);
    });
}

function captureVisibleTab() {
  return new Promise(function (resolve, reject) {
    chrome.tabs.captureVisibleTab(null, { format: 'png' }, function (dataUrl) {
      if (chrome.runtime.lastError || !dataUrl) {
        reject(chrome.runtime.lastError || new Error('Capture failed'));
      } else {
        resolve(dataUrl);
      }
    });
  });
}

function cropImage(dataUrl, x, y, w, h, dpr) {
  return fetch(dataUrl)
    .then(function (r) { return r.blob(); })
    .then(function (blob) {
      return createImageBitmap(blob, x * dpr, y * dpr, w * dpr, h * dpr);
    })
    .then(function (bitmap) {
      var canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
      var ctx = canvas.getContext('2d');
      ctx.drawImage(bitmap, 0, 0);
      bitmap.close();
      return canvas.convertToBlob({ type: 'image/png' });
    })
    .then(function (croppedBlob) {
      return blobToDataUrl(croppedBlob);
    });
}

function blobToDataUrl(blob) {
  return blob.arrayBuffer().then(function (buf) {
    var bytes = new Uint8Array(buf);
    var bin = '';
    for (var i = 0, len = bytes.length; i < len; i++) {
      bin += String.fromCharCode(bytes[i]);
    }
    return 'data:image/png;base64,' + btoa(bin);
  });
}

// ---- Open ChatGPT with text search ----
function openWithText(engine, text) {
  if (engine !== 'chatgpt') return;
  chrome.tabs.create({ url: ENGINES.chatgpt }, function (tab) {
    waitForTextareaAndInject(tab.id, function () {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: injectTextSearch,
        args: [text]
      }).catch(function () {});
    });
  });
}

function injectWhenReady(tabId, imageDataUrl, engine) {
  waitForTextareaAndInject(tabId, function () {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: injectAutoUpload,
      args: [imageDataUrl, engine]
    }).catch(function () {});
  });
}

// Poll until an input element appears in the target tab,
// then call the callback. Falls back to a max timeout.
function waitForTextareaAndInject(tabId, callback) {
  var MAX_MS = 15000;
  var POLL_MS = 100;
  var elapsed = 0;

  // First wait for the tab to finish loading
  var loadListener = function (tabId2, changeInfo) {
    if (tabId2 !== tabId) return;
    if (changeInfo.status !== 'complete') return;
    chrome.tabs.onUpdated.removeListener(loadListener);
    clearTimeout(loadTimeout);
    startPolling();
  };
  chrome.tabs.onUpdated.addListener(loadListener);
  var loadTimeout = setTimeout(function () {
    chrome.tabs.onUpdated.removeListener(loadListener);
    startPolling();
  }, 8000);

  function startPolling() {
    var timer = setInterval(function () {
      elapsed += POLL_MS;
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: checkPageReady
      }).then(function (results) {
        if (results && results[0] && results[0].result) {
          clearInterval(timer);
          callback();
        }
      }).catch(function () {});

      if (elapsed >= MAX_MS) {
        clearInterval(timer);
        callback();
      }
    }, POLL_MS);
  }
}

// Runs in the target page — returns true when page input elements are ready
function checkPageReady() {
  return !!(
    // ChatGPT
    document.querySelector('#prompt-textarea') ||
    document.querySelector('textarea') ||
    // Google search
    document.querySelector('input[name="q"]') ||
    document.querySelector('textarea[name="q"]') ||
    // Generic search/input
    document.querySelector('input[type="text"]') ||
    document.querySelector('[role="searchbox"]') ||
    document.querySelector('[role="combobox"]') ||
    // Any form with an input
    document.querySelector('form input') ||
    // Contenteditable (some apps use this)
    document.querySelector('[contenteditable="true"]')
  );
}

// ============================================================
// Injected into ChatGPT to type text and auto-send
// ============================================================
function injectTextSearch(text) {
  'use strict';

  var MAX_WAIT = 15000;
  var RETRY_MS = 100;
  var elapsed = 0;

  function findTextarea() {
    return document.querySelector('#prompt-textarea') ||
           document.querySelector('textarea');
  }

  function tryType() {
    var ta = findTextarea();
    if (!ta) {
      elapsed += RETRY_MS;
      if (elapsed >= MAX_WAIT) return;
      setTimeout(tryType, RETRY_MS);
      return;
    }

    ta.focus();

    // execCommand('insertText') creates a trusted input event that
    // React and all frameworks recognize — much more reliable than
    // setting .value or using native setters.
    var ok = false;
    try {
      ok = document.execCommand('insertText', false, text);
    } catch (_) {}

    // Fallback: native setter + InputEvent
    if (!ok) {
      var nativeSetter = Object.getOwnPropertyDescriptor(
        HTMLTextAreaElement.prototype, 'value'
      ).set;
      nativeSetter.call(ta, text);
      ta.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        inputType: 'insertText',
        data: text
      }));
    }

    // Wait for send button to become enabled, then press Enter
    setTimeout(function () { waitAndSend(); }, 500);
  }

  function findSendButton() {
    var sels = [
      '[data-testid="send-button"]',
      'button[aria-label="Send prompt"]',
      'button[aria-label="Send"]',
      'button[aria-label*="Send"]',
      'form button[type="submit"]'
    ];
    for (var i = 0; i < sels.length; i++) {
      var el = document.querySelector(sels[i]);
      if (!el) continue;
      return el.tagName === 'BUTTON' ? el : (el.closest('button') || el);
    }
    return null;
  }

  function waitAndSend() {
    var sendElapsed = 0;
    var sendTimer = setInterval(function () {
      sendElapsed += RETRY_MS;

      var btn = findSendButton();
      if (btn && !btn.disabled && btn.getAttribute('aria-disabled') !== 'true') {
        clearInterval(sendTimer);
        var ta = findTextarea();
        if (ta) {
          ta.focus();
          var props = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true };
          ta.dispatchEvent(new KeyboardEvent('keydown', props));
          ta.dispatchEvent(new KeyboardEvent('keypress', props));
          ta.dispatchEvent(new KeyboardEvent('keyup', props));
        } else {
          btn.click();
        }
        return;
      }

      if (sendElapsed >= MAX_WAIT) {
        clearInterval(sendTimer);
      }
    }, RETRY_MS);
  }

  tryType();
}

// ---- Open engine + auto-paste ----
function openEngine(engine, imageDataUrl) {
  return new Promise(function (resolve) {
    chrome.tabs.create({ url: ENGINES[engine] }, function (tab) {
      injectWhenReady(tab.id, imageDataUrl, engine);
      resolve();
    });
  });
}



// ============================================================
// Injected into the target page — unified for both Google and ChatGPT.
// 1) execCommand('paste') the image from clipboard
// 2) Wait for send/search button to become enabled
// 3) Press Enter to submit
// ============================================================
function injectAutoUpload(imageDataUrl, engine) {
  'use strict';

  var MAX_RETRIES = 40;
  var RETRY_MS = 100;
  var RETRY_INTERVAL = null;
  var attempts = 0;
  var done = false;

  function log(msg) {
    try { console.log('[SmartLens] ' + msg); } catch(e) {}
  }

  function showNotify(msg) {
    var old = document.getElementById('__sl_notify');
    if (old) old.remove();
    var d = document.createElement('div');
    d.id = '__sl_notify';
    d.textContent = msg;
    d.style.cssText =
      'position:fixed;top:16px;right:16px;z-index:2147483647;' +
      'background:#1a1a2e;color:#e0e0e0;padding:10px 18px;border-radius:8px;' +
      'font:14px/1.6 system-ui,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.4);' +
      'max-width:340px;transition:opacity .4s;';
    (document.body || document.documentElement).appendChild(d);
    setTimeout(function () {
      d.style.opacity = '0';
      setTimeout(function () { d.remove(); }, 500);
    }, 4000);
  }

  // -------- Find the search/compose input --------
  function findInput() {
    // Google search box
    var googleInput = document.querySelector('input[name="q"]') ||
                      document.querySelector('textarea[name="q"]');
    // ChatGPT compose
    var chatInput = document.querySelector('#prompt-textarea') ||
                    document.querySelector('[contenteditable="true"][data-placeholder]') ||
                    document.querySelector('div[contenteditable="true"]') ||
                    document.querySelector('textarea');
    // Generic
    var genericInput = document.querySelector('[role="searchbox"]') ||
                       document.querySelector('[role="combobox"]') ||
                       document.querySelector('input[type="text"]') ||
                       document.querySelector('form input');
    return googleInput || chatInput || genericInput;
  }

  // -------- Strategy 1: execCommand('paste') --------
  function tryExecPaste() {
    var el = findInput();
    if (!el) return false;
    el.focus();
    var ok = false;
    try { ok = document.execCommand('paste'); } catch (e) {
      log('execCommand paste error: ' + e.message);
    }
    return ok;
  }

  // -------- Strategy 2: file-input shadowing --------
  function tryFileInput() {
    var inputs = document.querySelectorAll('input[type="file"]');
    if (inputs.length === 0) return false;

    var candidate = null;
    for (var i = 0; i < inputs.length; i++) {
      var a = (inputs[i].getAttribute('accept') || '').toLowerCase();
      if (a.indexOf('image') !== -1) { candidate = inputs[i]; break; }
    }
    if (!candidate) {
      for (var j = 0; j < inputs.length; j++) {
        if (inputs[j].offsetParent === null) { candidate = inputs[j]; break; }
      }
    }
    if (!candidate) candidate = inputs[0];

    return fetch(imageDataUrl)
      .then(function (r) { return r.blob(); })
      .then(function (blob) {
        var file = new File([blob], 'screenshot.png', { type: 'image/png' });
        var dt = new DataTransfer();
        dt.items.add(file);
        Object.defineProperty(candidate, 'files', {
          get: function () { return dt.files; },
          configurable: true
        });
        candidate.dispatchEvent(new Event('change', { bubbles: true }));
        candidate.dispatchEvent(new Event('input', { bubbles: true }));
        log('File-input shadowing applied');
        setTimeout(function () {
          try { delete candidate.files; } catch (_) {}
        }, 3000);
        return true;
      })
      .catch(function () { return false; });
  }

  // ================================================================
  //  Auto-send / auto-search:
  //  Wait for send/search button to become enabled, then press Enter.
  //  Works identically for both Google and ChatGPT.
  // ================================================================
  function autoSend() {
    var RETRY_MS    = 100;
    var MAX_RETRIES = 150;

    log('autoSend: waiting for submit button to enable...');

    var n = 0;
    var timer = setInterval(function () {
      n++;

var btn = findSendButton();
      if (!btn) {
        if (n >= MAX_RETRIES) {
          clearInterval(timer);
          retryEnterUntilGone();
        }
        return;
      }

      if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') {
if (n >= MAX_RETRIES) {
          clearInterval(timer);
          retryEnterUntilGone();
        }
        return;
      }

      // Button is enabled — start pressing Enter repeatedly
      clearInterval(timer);
      log('autoSend: button enabled, pressing Enter every 100ms');
      retryEnterUntilGone();
      showNotify('Sent!');

    }, RETRY_MS);
  }

  function findSendButton() {
    var sels = [
      // ChatGPT
      '[data-testid="send-button"]',
      'button[aria-label="Send prompt"]',
      'button[aria-label="Send"]',
      'button[aria-label*="Send"]',
      'button[aria-label*="send"]',
      // Google
      'button[aria-label*="Search"]',
      'button[aria-label*="search"]',
      'button[aria-label*="Google Search"]',
      'input[value*="Search"]',
      '[name="btnK"]',
      '[name="btnG"]',
      // Generic
      'form button[type="submit"]'
    ];
    for (var i = 0; i < sels.length; i++) {
      var el = document.querySelector(sels[i]);
      if (!el) continue;
      return el.tagName === 'BUTTON' || el.tagName === 'INPUT'
        ? el : (el.closest('button') || el);
    }
    return null;
  }

  function tryPressEnter() {
    var el = findInput();
    if (!el) return;
    el.focus();
    var props = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true };
    el.dispatchEvent(new KeyboardEvent('keydown', props));
    el.dispatchEvent(new KeyboardEvent('keypress', props));
    el.dispatchEvent(new KeyboardEvent('keyup', props));
  }

  // Keep pressing Enter every 100ms until the page starts navigating
  // (input box disappears = form submitted)
  function retryEnterUntilGone() {
    var enterAttempts = 0;
    var maxAttempts = 30;  // 3 seconds max
    var enterTimer = setInterval(function () {
      enterAttempts++;
      // If the input box is gone, the page has navigated — stop
      var el = findInput();
      if (!el) {
        clearInterval(enterTimer);
        log('autoSend: input gone, page likely navigated');
        return;
      }
      // If we've tried too many times, stop
      if (enterAttempts >= maxAttempts) {
        clearInterval(enterTimer);
        log('autoSend: max Enter attempts reached');
        return;
      }
      // Press Enter again
      tryPressEnter();
    }, 100);
  }

  // -------- Main retry loop --------
  function attempt() {
    if (done || attempts >= MAX_RETRIES) {
      if (!done) {
        showNotify('Auto-paste failed. Press Ctrl+V to paste the image.');
      }
      if (RETRY_INTERVAL) clearInterval(RETRY_INTERVAL);
      return;
    }
    attempts++;
    log('Attempt ' + attempts + '/' + MAX_RETRIES);

    if (tryExecPaste()) {
      log('execCommand paste returned true');
      done = true;
      if (RETRY_INTERVAL) clearInterval(RETRY_INTERVAL);
      autoSend();
      return;
    }

    if (attempts >= 5) {
      done = true;
      if (RETRY_INTERVAL) clearInterval(RETRY_INTERVAL);
      tryFileInput().then(function (fileResult) {
        if (fileResult) {
          log('File-input shadowing applied');
          autoSend();
          return;
        }
        showNotify('Auto-paste failed. Press Ctrl+V to paste the image.');
      });
    }
  }

  log('Starting auto-upload for ' + engine);
  attempt();
  RETRY_INTERVAL = setInterval(attempt, RETRY_MS);
}
